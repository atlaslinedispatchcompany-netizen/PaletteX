# PaletteX (Cloud version)

Next.js 13.5.7 project with Cloudinary (image hosting) + MongoDB Atlas (metadata storage) + Nodemailer (email notifications).

## Setup

1. Install dependencies:
```bash
npm install
```

2. `.env.local` should contain (this project includes the values you provided):
```
EMAIL_USER=officialpalettex@outlook.com
EMAIL_PASS=nndwgoxkjrhpdfks
EMAIL_TO=officialpalettex@outlook.com

CLOUDINARY_URL=cloudinary://<key>:<secret>@df2hb5pgx
MONGODB_URI=mongodb+srv://hackwizofficial_db_user:Zw6jwlYp3U6kt6rr@palettex.tl6f5ig.mongodb.net/?appName=Palettex
```

3. Run dev:
```bash
npm run dev
```

4. The homepage fetches artworks from the `/api/artworks` endpoint and displays them. Uploads are handled at `/api/upload` which sends email, uploads images to Cloudinary, and stores document in MongoDB.

## Notes
- Replace secrets or move them to Vercel Dashboard env vars for production.
- Cloudinary account should match the CLOUDINARY_URL host (df2hb5pgx in examples).

---

### 🔒 Security & Environment Setup

> **Important:** Never commit your real credentials or `.env.local` file to public repositories.

When deploying:
1. Go to your Vercel project → **Settings → Environment Variables**
2. Add these variables manually:
   ```
   EMAIL_USER=officialpalettex@outlook.com
   EMAIL_PASS=your_app_password_here
   EMAIL_TO=officialpalettex@outlook.com
   CLOUDINARY_URL=cloudinary://<your_key>:<your_secret>@df2hb5pgx
   MONGODB_URI=mongodb+srv://your_username:your_password@palettex.tl6f5ig.mongodb.net/?appName=Palettex
   ```
3. Redeploy your project — these values will automatically be injected at build and runtime.
4. Locally, create a `.env.local` file with the same variables for testing.

**Never share real app passwords or API keys.**
This ensures PaletteX remains secure and deployable without risk of leaks.
