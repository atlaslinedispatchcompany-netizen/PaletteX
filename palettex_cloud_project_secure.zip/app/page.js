'use client'
import { useEffect, useState } from 'react';

export default function Home() {
  const [artworks, setArtworks] = useState([]);
  const [status, setStatus] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/artworks');
        const data = await res.json();
        setArtworks(data || []);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, []);

  return (
    <main style={{ fontFamily: 'sans-serif', padding: 24, maxWidth: 1100, margin: '0 auto' }}>
      <header style={{ textAlign: 'center', marginBottom: 24 }}>
        <h1>🎨 PaletteX</h1>
        <p>PaletteX – Where Artists and Collectors Connect</p>
      </header>

      <section style={{ display: 'grid', gridTemplateColumns: '1fr 420px', gap: 24 }}>
        <div>
          <h2>Featured Gallery</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
            {artworks.map((a) => (
              <div key={a._id} style={{ background: '#f3f3f3', padding: 8 }}>
                <img src={a.images?.[0]} alt={a.name} style={{ width: '100%', height: 160, objectFit: 'cover' }} />
                <div style={{ paddingTop: 8 }}>
                  <strong>{a.name}</strong>
                  <div>{a.price ? '$' + a.price : ''}</div>
                </div>
              </div>
            ))}
            {artworks.length === 0 && <div style={{ gridColumn: '1/-1', color: '#666' }}>No artworks yet.</div>}
          </div>
        </div>

        <aside style={{ border: '1px solid #eee', padding: 16, borderRadius: 8 }}>
          <h3>Upload Artwork</h3>
          <form id="uploadForm" encType="multipart/form-data" onSubmit={async (e)=>{
            e.preventDefault();
            setStatus('Uploading...');
            const form = new FormData(e.target);
            try {
              const res = await fetch('/api/upload', { method: 'POST', body: form });
              const data = await res.json();
              if (res.ok) {
                setStatus('Upload sent — check admin email and gallery.');
                e.target.reset();
                // refresh gallery
                const r = await fetch('/api/artworks');
                const d = await r.json();
                setArtworks(d || []);
              } else {
                setStatus('Upload failed: ' + (data.error || res.statusText));
              }
            } catch (err) {
              setStatus('Upload error: ' + err.message);
            }
          }}>
            <label style={{ display: 'block', marginBottom: 8 }}>
              Name<br/>
              <input name="name" required style={{ width: '100%' }} />
            </label>

            <label style={{ display: 'block', marginBottom: 8 }}>
              Email<br/>
              <input name="email" type="email" required style={{ width: '100%' }} />
            </label>

            <label style={{ display: 'block', marginBottom: 8 }}>
              Price Offer (USD)<br/>
              <input name="price" type="number" step="0.01" style={{ width: '100%' }} />
            </label>

            <label style={{ display: 'block', marginBottom: 8 }}>
              Message<br/>
              <textarea name="message" rows={4} style={{ width: '100%' }}></textarea>
            </label>

            <label style={{ display: 'block', marginBottom: 8 }}>
              Images (multiple)<br/>
              <input name="images" type="file" multiple accept="image/*" />
            </label>

            <button type="submit" style={{ marginTop: 8 }}>Send to PaletteX</button>
          </form>

          <div style={{ marginTop: 12, fontSize: 14, color: '#555' }}>{status}</div>
        </aside>
      </section>

      <footer style={{ marginTop: 36, textAlign: 'center', color: '#777' }}>
        © PaletteX — Artists & Collectors
      </footer>
    </main>
  )
}
