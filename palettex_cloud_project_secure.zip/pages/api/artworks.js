import { connectToDatabase } from '../../lib/mongodb';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const { db } = await connectToDatabase();
  const items = await db.collection('artworks').find({}).sort({ createdAt: -1 }).toArray();
  res.status(200).json(items);
}
