import formidable from 'formidable';
import fs from 'fs';
import nodemailer from 'nodemailer';
import { v2 as cloudinary } from 'cloudinary';
import path from 'path';
import { connectToDatabase } from '../../lib/mongodb';

export const config = { api: { bodyParser: false } };

const parseForm = (req) => new Promise((resolve, reject) => {
  const form = formidable({
    multiples: true,
    keepExtensions: true,
    maxFileSize: 20 * 1024 * 1024
  });
  form.parse(req, (err, fields, files) => {
    if (err) return reject(err);
    resolve({ fields, files });
  });
});

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { fields, files } = await parseForm(req);
    const name = fields.name || 'Unknown';
    const email = fields.email || '';
    const message = fields.message || '';
    const price = fields.price || '';

    let images = [];
    if (files.images) {
      images = Array.isArray(files.images) ? files.images : [files.images];
    }

    // Configure cloudinary from env
    cloudinary.config({ secure: true });

    const uploadedUrls = [];
    for (const f of images) {
      const filepath = f.filepath || f.path || f.file;
      const resp = await cloudinary.uploader.upload(filepath, { folder: 'palettex_uploads' });
      uploadedUrls.push(resp.secure_url);
      try { fs.unlinkSync(filepath); } catch(e) {}
    }

    // Store in MongoDB
    const { db } = await connectToDatabase();
    const doc = { name, email, message, price, images: uploadedUrls, createdAt: new Date() };
    const result = await db.collection('artworks').insertOne(doc);

    // Send email
    const transporter = nodemailer.createTransport({
      host: 'smtp.office365.com',
      port: 587,
      secure: false,
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_TO || process.env.EMAIL_USER,
      subject: `PaletteX Upload from ${name} <${email}>`,
      text: `Name: ${name}\nEmail: ${email}\nPrice Offer: ${price}\nMessage:\n${message}\nImages:\n${uploadedUrls.join('\n')}`
    };

    await transporter.sendMail(mailOptions);

    return res.status(200).json({ ok: true, id: result.insertedId });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: String(err) });
  }
}
